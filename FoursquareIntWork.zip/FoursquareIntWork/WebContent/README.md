Purpose of the project is to create a demo showing how an integration with Foursquare API can be achieved.
The VenuesResource class is a servlet accepting as a parameter "name" being the Place in which we want to find the Venues near by.

Example:
http://localhost:8080/FoursquareIntWork/VenuesResource?name=Bucharest

The Web page will display a table containing the found venues in Bucharest, with Venue Name and Venue Address as listed information. Also I chose to list the JSON Object created for the Venues Result.

For developing the application I used <br />
 - Eclipse Luna <br />
 - Tomcat 8.0 <br />
 - log4j library <br />
 - Java Json library <br />
 - foursquare-api library <br />
 - junit library <br />
 
Java classes developed for this integration are in WEB-INF/classe in main.java.com packages.