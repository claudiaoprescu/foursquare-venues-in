package main.java.com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;
import org.json.JSONObject;

import main.java.com.exception.LocationNotFoundException;
import main.java.com.exception.ParamMissingException;
import main.java.com.resources.VenueBeans;
import main.java.com.utils.Constants;
import main.java.com.utils.HTMLProcessor;
import main.java.com.utils.ResourceValidator;
import fi.foyt.foursquare.api.FoursquareApiException;
import fi.foyt.foursquare.api.Result;
import fi.foyt.foursquare.api.entities.VenuesSearchResult;

public class VenuesResource extends HttpServlet {

	private static final long serialVersionUID = -4963245125045733155L;

	/**
	 * get Venues servlet
	 * 
	 * @param HttpServletRequest
	 *            req
	 * @param HttpServletResponse
	 *            res
	 * @throws ServletException
	 * @throws IOException
	 */

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {

		String placeName = req.getParameter(Constants.INPUT_PARAM);

		/*
		 * Validate input parameter
		 */
		try {
			ResourceValidator.isStringParameterAvailable(placeName);
		} catch (ParamMissingException e) {
			throw new ServletException(e);
		}

		VenueBeans venueBeans = new VenueBeans();
		Result<VenuesSearchResult> venues;
		JSONObject venuesList;
		try {
			/*
			 * Retrieve venues using Foursquare API
			 */
			venues = venueBeans.searchVenues(placeName);
			/*
			 * Parse venues list and create JSON Object
			 */
			venuesList = venueBeans.prepareResult(venues);
		} catch (FoursquareApiException e) {
			throw new ServletException("Error in Foursquare API" + e);
		} catch (LocationNotFoundException e) {
			throw new ServletException(e);
		} catch (JSONException e) {
			throw new ServletException(e);
		}

		/*
		 * Create HTML file for data listing purpose
		 */
		HTMLProcessor html = new HTMLProcessor();
		String dataToPrintasHtml = html.addData(venues);

		res.setContentType("text/html");
		// Get the printwriter object from response to write the required json
		// object to the output stream
		PrintWriter out = res.getWriter();

		// Print html file built
		out.print(dataToPrintasHtml);

		// Return JSONArray
		out.print(System.getProperty("line.separator")
				+ "Print result as JSON:"
				+ System.getProperty("line.separator"));
		out.print(venuesList);
		out.flush();

	}
}