package main.java.com.utils;

public class Constants {

	public static final String CLIENT_ID = "LA0HJNCCMB2IHME3E5F0HAONHJTKFUIXBMSFXM0BXQTG204W";
	public static final String CLIENT_SECRET = "JTW432HQ24XQBL15L3P3LIB3QVGCNPGY53IT4YTNAT2QDU0P";

	public static final String JSON_VENUE_NAME = "venue_name";
	public static final String JASON_VENUE_POSTAL_CODE = "postal_code";
	public static final String JASON_OBJECT_HEADER = "venues";

	public static final String HTML_NAME = "VenuesList.html";

	public static final String INPUT_PARAM = "name";

}
