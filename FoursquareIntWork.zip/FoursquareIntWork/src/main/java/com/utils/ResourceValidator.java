package main.java.com.utils;

import javax.servlet.ServletException;

import main.java.com.exception.ParamMissingException;

public class ResourceValidator {

	/**
	 * Checks that a string is not null(available)
	 * 
	 * @param String
	 *            parameter
	 * @throws ParamMissingException
	 * @throws ServletException
	 */
	public static void isStringParameterAvailable(String parameter)
			throws ParamMissingException {
		if (parameter == null || parameter.trim().length() <= 0)
			throw new ParamMissingException("HTTPMessages.Missing_Venue_name");
	}
}
