package main.java.com.utils;

import java.util.Optional;

public class VenuesUtil {

	/**
	 * Method ensures if address is not found for a Venue, it will return a
	 * meaningful String instead of null
	 * 
	 * @param String
	 *            address
	 * @return address - The address for a Venue
	 */

	public static String getLocationAddress(String address) {
		if (!Optional.ofNullable(address).isPresent()) {
			return "Address not specified for this Venue";
		} else {
			return address;
		}

	}

}
