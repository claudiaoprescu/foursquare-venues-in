package main.java.com.utils;

import java.io.IOException;

import fi.foyt.foursquare.api.Result;
import fi.foyt.foursquare.api.entities.CompactVenue;
import fi.foyt.foursquare.api.entities.VenuesSearchResult;

public class HTMLProcessor {

	/**
	 * Method used to create HTML file to structure data in browser
	 * 
	 * @param Result
	 *            <VenuesSearchResult> venues - Venues list
	 *
	 * @throws IOException
	 */

	public String addData(Result<VenuesSearchResult> venues) throws IOException {

		StringBuilder writer = new StringBuilder();

		writer.append("<!DOCTYPE html>" + "<html>" + "<head>"
				+ "<meta charset=\"ISO-8859-1\">" + "<title>Venues</title>");

		/*
		 * Add CSS data
		 */
		addCSSData(writer);

		writer.append("</head>" + "<body>");
		writer.append("<table align=\"center\">");
		writer.append("<tr>");
		writer.append("<td id=\"header\" colspan=\"7\"><h1>Result of your venues search:</h1></td>");
		writer.append("</tr>");
		writer.append("<tr>");
		writer.append("<th>Venue Name</th>");
		writer.append("<th>Venue Address</th>");
		writer.append("</tr>");

		/*
		 * Add Venues to the HTML table
		 */

		for (CompactVenue venue : venues.getResult().getVenues()) {
			writer.append("<tr>");
			writer.append("<td>" + venue.getName() + "</td>");
			writer.append("<td>"
					+ VenuesUtil.getLocationAddress(venue.getLocation()
							.getAddress()) + "</td>");
			writer.append("</tr>");
		}

		writer.append("</table>");
		writer.append("</body></html>");

		return writer.toString();

	}

	/**
	 * Method used to add specific CSS part to the HTML file
	 * 
	 * @param StringBuilder
	 *            writer
	 *
	 */

	public StringBuilder addCSSData(StringBuilder writer) {

		writer.append("<style>");
		/*
		 * CSS for Body
		 */
		writer.append("body { font-family: sans-serif; font-size: 11pt; background-color: #fce8ba; }");

		/*
		 * CSS for table only
		 */
		writer.append("table { width: 80%; }");

		/*
		 * CSS for table, header cells and data cells
		 */
		writer.append("table, th, td { border: 1px solid black; border-collapse: collapse; opacity: 0.95; }");

		/*
		 * CSS for header and data cells alignment
		 */
		writer.append("th, td { padding: 10px; text-align: center; }");

		/*
		 * CSS for header cell only
		 */
		writer.append("th { background-color: #a70000; color: white; }");

		/*
		 * CSS for header cell only to color even and odd
		 */
		writer.append("tr:nth-child(even) { background-color: #e3e3df; }");
		writer.append("tr:nth-child(odd) { background-color: white; }");

		/*
		 * CSS to only color the header cell
		 */
		writer.append("#header { background-color: #93938f; color: white }");

		writer.append("</style>");

		return writer;

	}
}
