package main.java.com.resources;

import main.java.com.exception.LocationNotFoundException;
import fi.foyt.foursquare.api.FoursquareApiException;
import fi.foyt.foursquare.api.Result;
import fi.foyt.foursquare.api.entities.VenuesSearchResult;

public interface Venue {

	public Result<VenuesSearchResult> searchVenues(String venueName)
			throws FoursquareApiException, LocationNotFoundException;

}
