package main.java.com.resources;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;

import main.java.com.exception.LocationNotFoundException;
import main.java.com.utils.Constants;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import fi.foyt.foursquare.api.FoursquareApi;
import fi.foyt.foursquare.api.FoursquareApiException;
import fi.foyt.foursquare.api.Result;
import fi.foyt.foursquare.api.entities.CompactVenue;
import fi.foyt.foursquare.api.entities.VenuesSearchResult;

public class VenueBeans implements Venue {

	final static Class<VenueBeans> CLASS_NAME = VenueBeans.class;
	final static Logger logger = Logger.getLogger(CLASS_NAME);

	/**
	 * Custom method used to search Venues near a given location
	 * 
	 * @param String
	 *            placeName - location name near which venues will be searched
	 * @throws FoursquareApiException
	 * @throws LocationNotFoundException
	 */
	public Result<VenuesSearchResult> searchVenues(String placeName)
			throws FoursquareApiException, LocationNotFoundException {
		logger.info("Entered method searchVenues in: " + CLASS_NAME.getName());
		// Initialize FoursquareApi.
		FoursquareApi foursquareApi = new FoursquareApi(Constants.CLIENT_ID,
				Constants.CLIENT_SECRET, "");

		DateFormat dateFormat = new SimpleDateFormat("YYYYMMDD");
		Date date = new Date();

		if (logger.isDebugEnabled()) {
			logger.debug(CLASS_NAME.getName() + " Date Format: "
					+ dateFormat.format(date));
		}

		foursquareApi.setVersion(dateFormat.format(date));

		// Search for venues based on the place specified
		Result<VenuesSearchResult> venues = foursquareApi.venuesSearch(null,
				null, null, null, null, null, null, null, null, null, null,
				null, placeName);
		// If response is not success throw error
		if (venues.getMeta().getCode() != 200) {
			logger.error(CLASS_NAME.getName() + "Error in Foursquare API!",
					new FoursquareApiException("Error: "
							+ venues.getMeta().getCode()
							+ venues.getMeta().getErrorType()
							+ venues.getMeta().getErrorDetail()));
		}

		Optional<Result<VenuesSearchResult>> optionVenues = Optional.of(venues);
		if (!optionVenues.isPresent()) {
			logger.error(CLASS_NAME.getName(), new LocationNotFoundException(
					"No Venue was found on the specified location!"));
		}

		logger.info("Leaving method searchVenues in: " + CLASS_NAME.getName());
		// return near venues based on found location
		return venues;

	}

	/**
	 * Custom method used to parse Venues result and create JSON Object
	 * 
	 * @param String
	 *            venues - Venues result
	 * @throws JSONException
	 */

	public JSONObject prepareResult(Result<VenuesSearchResult> venues)
			throws JSONException {
		logger.info("Entered method prepareResult in: " + CLASS_NAME.getName());

		JSONArray venuesArray = new JSONArray();
		JSONObject venuesJson = new JSONObject();

		for (CompactVenue venue : venues.getResult().getVenues()) {
			JSONObject newVenue = new JSONObject();
			newVenue.append(Constants.JSON_VENUE_NAME, venue.getName());
			newVenue.append(Constants.JASON_VENUE_POSTAL_CODE, venue
					.getLocation().getAddress());
			venuesArray.put(newVenue);
		}
		venuesJson.append(Constants.JASON_OBJECT_HEADER, venuesArray);

		logger.info("Leaving method prepareResult in: " + CLASS_NAME.getName());

		return venuesJson;

	}
}
