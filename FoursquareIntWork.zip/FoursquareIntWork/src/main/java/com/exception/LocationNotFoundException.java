package main.java.com.exception;


public class LocationNotFoundException extends Throwable {

	private static final long serialVersionUID = 5617770350567496322L;

	/**
	 * Custom defined error
	 * 
	 * @param String
	 *            message
	 * @throws LocationNotFoundException
	 */

	public LocationNotFoundException(String message)
			throws LocationNotFoundException {
		super("An exception happened in FoursquareAPI processing" + message);
	}

}
