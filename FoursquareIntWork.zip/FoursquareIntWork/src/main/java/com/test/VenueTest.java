package main.java.com.test;

import main.java.com.exception.LocationNotFoundException;
import main.java.com.resources.VenueBeans;

import org.junit.Test;

import fi.foyt.foursquare.api.FoursquareApiException;

public class VenueTest {

	@Test
	public void testCannotTakeNullValue() {

		VenueBeans venue = new VenueBeans();
		try {
			venue.searchVenues(null);
		} catch (FoursquareApiException | LocationNotFoundException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testCannotTakeEmptyValue() {

		VenueBeans venue = new VenueBeans();
		try {
			venue.searchVenues("");
		} catch (FoursquareApiException | LocationNotFoundException e) {
			e.printStackTrace();
		}

	}
}
